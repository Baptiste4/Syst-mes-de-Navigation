#include "stm32f4xx_hal.h"
#include "stm32f4xx_it.h"
#include "stm32f4xx_hal_i2c.h"

//ADRESSES DES COMPOSANTS POUR LA sen0140
#define compasAddress 0x3C
#define accelAddress 0xA6
#define gyroAddress 0xD0
#define baroAdress 0xEE

//BUS I2C UTILISÉ
I2C_HandleTypeDef hi2c1;

//DÉCLARATIONS DES FONCTIONS
void scanner_I2C(void);					//Récupération des adresses présentes sur le BUS
void calib_BMP(void);					//Lecture des registres de calibraton du BMP
uint8_t acqu_Accelerometre(void);		//Acquisition des données de l'accéléromètre
uint8_t acqu_Barometre(void);			//Acquisition des données de température et pression
uint8_t acqu_Compas(void);				//Acquisition de l'orientation magnétique
uint8_t acqu_Gyro(void);				//Acquisition du gyroscope
void reInitVarGlobales(void);			//Réinitialisation des variables
void MX_I2C1_Init(void);				//Initialisation de l'I2C
uint8_t enable_I2C(void);				//Renvoie de l'ENABLE dans le main

