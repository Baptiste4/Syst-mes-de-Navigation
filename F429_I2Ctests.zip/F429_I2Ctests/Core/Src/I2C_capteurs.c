#include "I2C_capteurs.h"


//VARIABLES ACCELEROMETRE
uint16_t ax, ay, az;
float Xaccel, Yaccel, Zaccel, roll,pitch;
//VARIABLES BAROMETRE
int32_t c3=0,c4=0,b1=0,c5=0,c6=0;mc=0,md=0;
int32_t x0=0,x1=0,x2=0,y00=0,y11=0,y22=0,p0=0,p1=0,p2=0;
int32_t Temperature=0;
float Pression=0;
//VARIABLES COMPAS
float comp_X=0,comp_Y=0,comp_Z=0,comp_D = 0;
uint8_t direction = 0;
//VARIABLE GYROSCOPE
int16_t gyro_X=0,gyro_Y=0,gyro_Z=0;
//ENABLE DE L'ACQUISITION
uint8_t Enable;

//========================= SCANNER ======================
void scanner_I2C(){							//À utiliser en mode "pas à pas" et analyser les valeurs
	for(uint8_t i =0 ; i<255 ; i++){		//de i pour lesquels la condition est vérifiée
		if(HAL_I2C_IsDeviceReady(&hi2c1, i, 5, 10)==HAL_OK){
	            HAL_GPIO_TogglePin(GPIOG, GPIO_PIN_13);
	    }
	}
}

//============================ ENABLE DE l'ACQUISITION =======================================
uint8_t get_enable_I2C(){
	return Enable;
}

void EXTI0_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI0_IRQn 0 */
	if(Enable < 2)Enable ++;
  /* USER CODE END EXTI0_IRQn 0 */
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_0);
  /* USER CODE BEGIN EXTI0_IRQn 1 */

  /* USER CODE END EXTI0_IRQn 1 */
}
//============ RÉ-INITIALISATION DES VARIABLES LORS DU DISABLE DE L'ACQUISITION ====================

void reInitVarGlobales(){
	Xaccel = Yaccel = Zaccel = ax = ay = az = roll = pitch
	= Temperature = Pression
	= gyro_X = gyro_Y = gyro_Z
	=comp_X = comp_Y = comp_Z = comp_D
	= Enable
	= 0;
}

//===================== BAROMETRE BMP085 ==============================


void calib_BMP(){
	uint8_t calibBaroBuf[24]={0};
	int16_t AC1, AC2, AC3,AC4,AC5,AC6,B1,B2,MB,MC,MD;

	HAL_I2C_Mem_Read(&hi2c1, baroAdress, 0xAA, 1, calibBaroBuf, 22, 5); //Lecture de tous les registres de calibration
	AC1 = calibBaroBuf[0]<<8 | calibBaroBuf[1];									//Valeur attendue : 408 8288
	AC2 = calibBaroBuf[2]<<8 | calibBaroBuf[3];									//Valeur attendue : -72
	AC3 = calibBaroBuf[4]<<8 | calibBaroBuf[5];									//Valeur attendue : -14383
	AC4 = calibBaroBuf[6]<<8 | calibBaroBuf[7];									//Valeur attendue : 32741
	AC5 = calibBaroBuf[8]<<8 | calibBaroBuf[9];									//Valeur attendue : 32757
	AC6 = calibBaroBuf[10]<<8 | calibBaroBuf[11];								//Valeur attendue : 23153
	B1 = calibBaroBuf[12]<<8 | calibBaroBuf[13];								//Valeur attendue : 6190
	B2 = calibBaroBuf[14]<<8 | calibBaroBuf[15];								//Valeur attendue : -4
	MB = calibBaroBuf[16]<<8 | calibBaroBuf[17];								//Valeur attendue : -32768
	MC = calibBaroBuf[18]<<8 | calibBaroBuf[19];								//Valeur attendue : -8711
	MD = calibBaroBuf[20]<<8 | calibBaroBuf[21];								//Valeur attendue : 2868

	//Calcul des constantes
	c3 = 160*pow(2,-15)*AC3;
	c4 = 0.001*pow(2,-15)*AC4;
	b1 = pow(160,2)*pow(2,-30)*B1;

	//Constantes pour le calcul de la température
	c5 = (pow(2,-15)/160) *AC5;
	c6 = AC6;
	mc = (pow(2,11)/pow(160,2))*MC;
	md = MD / 160;

	//Constantes pour la pression
	x0=AC1;
	x1=160*pow(2,-13)*AC2;
	x2=pow(160,2)*pow(2,-25)*B2;

	y00 = c4 * pow(2,15);
	y11 = c4 * c3;
	y22 = c4 * b1;

	p0 = (3791-8)/1600;
	p1 = 1-7357 * pow(2,-20);
	p2 = 3038 * pow(2,-36);
}

uint8_t acqu_Barometre(){

	int32_t alpha=0,x=0,y=0,z=0;
	int8_t s = 0;
	uint8_t Data = 0;
	//Variables locales
	int32_t TempBrut=0,	X1temp=0,X2temp=0,B5=0;
	int32_t PresBrut=0,X1pres=0,X2pres=0,X3pres=0,B3=0,B6=0;
	uint32_t B4=0, B7=0;
	uint8_t acquBaroBuf[5]={0};

	//Acquisition de la température non-compensée
	Data = 0x2E;
	HAL_I2C_Mem_Write(&hi2c1, baroAdress, 0xF4, 1, &Data, 1, 10);			//Demande de mesure
	HAL_Delay(5);
	HAL_I2C_Mem_Read(&hi2c1, baroAdress, 0xF6, 1, &acquBaroBuf, 2, 10);		//Lecture de la mesure
	TempBrut = (acquBaroBuf[0]<<8)+ acquBaroBuf[1];

	//Acquisition de la pression non-compensée
	Data = 0x34;
	HAL_I2C_Mem_Write(&hi2c1, baroAdress, 0xF4, 1, &Data, 1, 10);			//Demande de mesure
	HAL_Delay(4.5);
	HAL_I2C_Mem_Read(&hi2c1, baroAdress, 0xF6, 1, &acquBaroBuf, 3, 10);		//Lecture de la mesure
	PresBrut = acquBaroBuf[0]<<16 | acquBaroBuf[1]<<8 | acquBaroBuf[2];

	//Calcul de la température
	alpha = c5*(TempBrut-c6);
	Temperature = alpha + (mc/(alpha + md));

	//Calcul de la pression
	s = Temperature - 25;
	x = x2*pow(s,2)+x1*s+x0;
	y = y22*pow(s,2)+y11*s+y00;
	if(y!=0)z = (PresBrut-x)/y;
	else z=PresBrut-x;
	Pression = p2*pow(z,2)+p1*z+p0;


	/* CALCUL RELATIF AU 180
	//Calcul de la température réelle
	X1temp=(TempBrut-AC6)*(AC5 / pow(2,15));
	X2temp= (MC*pow(2,11)) / (X1temp+MD);
	B5 = X1temp + X2temp;
	Temperature = (B5+8)/16 /10;

	//Calcul de la pression réelle
	B6 = B5 - 4000;
	X1pres = (B2*(B6*B6/pow(2,12)))/pow(2,11);
	X2pres = AC2*B6/pow(2,11);
	X3pres = X1pres + X2pres;
	B3 = ((AC1*4+X3pres)+2)/4;
	X1pres=AC3*B6/pow(2,13);
	X2pres=(B1*(B6*B6/pow(2,12)))/pow(2,16);
	X3pres=((X1pres+X2pres)+2)/4;
	B4=AC4*((unsigned long) X3pres+pow(1,15))/pow(2,15);
	B7=((unsigned long)PresBrut - B3)*50000;
	if(B7<0x80000000){Pression=(B7*2)/B4;}
	else{Pression=(B7/B4)*2;}
	X1pres=(Pression/pow(2,8))*(Pression/pow(2,8));
	X1pres=(X1pres*3038)/pow(2,16);
	X2pres=(-7357*Pression)/pow(2,16);
	Pression = Pression + (X1pres+X2pres+3791)/16 / 100;*/

	return 1;

}


//============================== CAPTEUR COMPAS HMC5883L =======================

uint8_t acqu_Compas(){

	uint8_t i2cCompBuf[8]={0};
	uint8_t Data = 0x30;
	int16_t acquCompX = 0, acquCompY = 0, acquCompZ = 0;

	HAL_I2C_Mem_Write(&hi2c1,compasAddress,0,1,&Data,1,10);
	Data = 0x01;
	if(HAL_I2C_Mem_Write(&hi2c1,compasAddress,0x02,1,&Data,1,10)==HAL_ERROR) return 2;		//Single measurement mode, adresse 0x02 valeur 0
	HAL_Delay(30);
	if(HAL_I2C_Mem_Read(&hi2c1, compasAddress, 0x03, 1, i2cCompBuf, 6, 10)==HAL_ERROR) return 2;
	acquCompX = i2cCompBuf[0]<<8 | i2cCompBuf[1];
	acquCompY = i2cCompBuf[4]<<8 | i2cCompBuf[5];
	acquCompZ = i2cCompBuf[2]<<8 | i2cCompBuf[3];

	acquCompX = ~(acquCompX-1);										//Data données sous forme de complement à 2
	acquCompY = ~(acquCompY-1);
	acquCompZ = ~(acquCompZ-1);

	comp_X = acquCompX *0.92/1000;										//Conversion en Gauss en appliquant le LSB (0.92 mG default)
	comp_Y = acquCompY *0.92/1000;
	comp_Z = acquCompZ *0.92/1000;

    if((comp_X == 0) & (comp_Y < 0)){comp_D = 90;}					//Conversion en coordonnées polaires
	else if ((comp_X == 0) & (comp_Y >= 0)){comp_D=0;}
	else {comp_D = atan(comp_Y / comp_X)* (180 / 3.141592);}

	if(comp_D>360){comp_D -= 360;}
	else if(comp_D<0){comp_D += 360;}

	//1 = N ; 2 = N-E; 3 = E; 4 = S-E ; 5 = S ; 6 = S-O ; 7 = O; 8 = N-O
	if((comp_D<67.5)){direction = 2;}								//NORD-EST
	else if((comp_D<112.5) & (comp_D>67.5) ){direction=3;}			//EST
	else if((comp_D<157.5) & (comp_D >112.5) ){direction=4;}		//SUD-EST
	else if((comp_D<202.5) & (comp_D >157.5) ){direction=5;}		//SUD
	else if((comp_D<247.5) & (comp_D >202.5) ){direction=6;}		//SUD-OUEST
	else if((comp_D<292.5) & (comp_D >247.5) ){direction=7;}		//OUEST
	else if((comp_D<337.5) & (comp_D >292.5) ){direction=8;}		//NORD-OUEST
	else{direction=1;}												//NORD
	return 1;

}

//====================== ACCELEROMETRE ADXL345 ===================================

uint8_t acqu_Accelerometre(){

	uint8_t i2cAccelBuf[8]={0};
	uint8_t Data=8;
	ax=ay=az=Xaccel=Yaccel=Zaccel=0;

	if(HAL_I2C_Mem_Write(&hi2c1, accelAddress, 0x2D, 1, &Data, 1, 10)==HAL_ERROR) return 2;				//Accéléromètre en mode "mesure"
	HAL_Delay(10);																						//Temps de mesure et conversion
	if(HAL_I2C_Mem_Read(&hi2c1, accelAddress, 0x32,1,i2cAccelBuf,6,10)==HAL_ERROR) return 2;			//Récupération des données mesurées
  	ax = (i2cAccelBuf[1]<<8 | i2cAccelBuf[0]);															//Concaténation de la donnée
  	ay = (i2cAccelBuf[3]<<8 | i2cAccelBuf[2]);
  	az = (i2cAccelBuf[5]<<8 | i2cAccelBuf[4]);

  	uint16_t x = 0,y=0,z=0;

  	x = i2cAccelBuf[0] + 256 * i2cAccelBuf[1];
  	y = i2cAccelBuf[2] + 256 * i2cAccelBuf[3];
  	z = i2cAccelBuf[4] + 256 * i2cAccelBuf[5];

  	double testx = 0;
  	testx = x;
  	if((i2cAccelBuf[1]>>7) == 1)  {
  		x=(~x+1);
  		testx = -x;
  	}

  	double testy = 0;
   	testy = y;
  	if((i2cAccelBuf[1]>>7) == 1)  {
  		y=(~y+1);
  		testy = -y;
  	}

  	double testz = 0;
  	testz = z;
  	if((i2cAccelBuf[1]>>7) == 1)  {
  		z=(~z+1);
  		testz = -z;
  	}

  	Xaccel = ~(x-1);																			//Conversion en g
  	Yaccel = ~(y-1);
  	Zaccel = ~(z-1);

  	roll = atan2(Yaccel , sqrt(pow(Xaccel,2)+pow(Zaccel,2)))*180/3.141592;
  	pitch = atan2(-1 * Xaccel , sqrt( pow(Yaccel,2)+pow(Zaccel,2) ) ) *180/3.141592;

  	return 1;
}

//======================== GYROSCOPE ITG 3200 =========================

uint8_t acqu_Gyro(){
	uint8_t i2cGyrBuf[8]={0};
	if(HAL_I2C_Mem_Read(&hi2c1, gyroAddress, 0x1D, 1, i2cGyrBuf,6,10)==HAL_ERROR) return 2;	//Lecture des 6 registres de donnée

	gyro_X = i2cGyrBuf[0]<<8 | i2cGyrBuf[1];
	gyro_Y = i2cGyrBuf[2]<<8 | i2cGyrBuf[3];
	gyro_Z = i2cGyrBuf[4]<<8 | i2cGyrBuf[5];

	gyro_X = ~(gyro_X -1);						//Donné envoyée en complément à 2
	gyro_Y = ~(gyro_Y -1);
	gyro_Z = ~(gyro_Z -1);

	return 1;
}

//====================== INITIALISATION DE L'I2C =======================
void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 50000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}
