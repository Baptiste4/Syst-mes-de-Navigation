/*
 *Fichier contenant les corps des fonctions utilisées pour
 * l'acquisition des capteurs de la centrale inertielle.
 *
 */

//Inclusion des fichiers
#include "I2C_centrale.h"

//Variables globales pour le BMP280
int16_t dig_T2, dig_T3, dig_P2, dig_P3, dig_P4, dig_P5, dig_P6, dig_P7, dig_P8, dig_P9;		//Valeur des registres de calibration
uint16_t dig_T1, dig_P1;

float Pression,Temperature;

//Variables globales pour le MPU9250, accelerometre et gyroscope
int16_t acq_AccelX,acq_AccelY,acq_AccelZ;
int16_t acq_GyroX,acq_GyroY,acq_GyroZ;
int16_t acq_Temp;
float AccelX,AccelY,AccelZ,Temp,GyroX,GyroY,GyroZ;

//Variables globales pour le MPU9250 magnetometre
float Magn_CalibX,Magn_CalibY,Magn_CalibZ;
float MagnX, MagnY, MagnZ;

//Enable de l'acquisition
uint8_t Enable_acq;

//Variables globales pour l'échantillonage
uint8_t ech_indice_A=0, ech_indice_M=0;
float tab_ech_accelX[10]={0}, tab_ech_accelY[10]={0}, tab_ech_accelZ[10]={0};
float ech_AccelX,ech_AccelY,ech_AccelZ;
float tab_ech_gyroX[10]={0}, tab_ech_gyroY[10]={0}, tab_ech_gyroZ[10]={0};
float ech_GyroX,ech_GyroY,ech_GyroZ;
float tab_ech_magnX[10]={0},tab_ech_magnY[10]={0},tab_ech_magnZ[10]={0};
float ech_MagnX,ech_MagnY,ech_MagnZ;


//========================================= FONCTIONS D'INITIALISATION =============================================================

// Lecture des registres de calibration du BMP280, et configuration du système en marche forcée
void BMP280_Init(){

	  uint8_t Chip_Id = 0; 										// Valeur du registre Chip_Id permettant de vérifier que la liaison est valide
	  uint8_t i2cCalibBuf[24] = {0};      						// Tableau de stockage des données récupérées
	  uint8_t Data_sent;

	  HAL_I2C_Mem_Read(&hi2c1, BMP280_Address, 0xD0, 1, &Chip_Id,1, 10); 	  // Lecture du registre d'identification du BMP180 (0xD0) qui contient la valeur 0x58
		  if(Chip_Id!=0x58){
			  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3 ,0);
	      }else {
	    	  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3,1);

			  HAL_I2C_Mem_Read(&hi2c1, BMP280_Address, REG_BMP_CALIBRATION, 1, i2cCalibBuf,24, 10);		//Récupération des données de calibration

			  dig_T1 = ((i2cCalibBuf[1]  << 8) | i2cCalibBuf[0])  ;
			  dig_T2 = ((i2cCalibBuf[3]  << 8) | i2cCalibBuf[2])  ;
			  dig_T3 = ((i2cCalibBuf[5]  << 8) | i2cCalibBuf[4])  ;
			  dig_P1 = ((i2cCalibBuf[7]  << 8) | i2cCalibBuf[6])  ;
			  dig_P2 = ((i2cCalibBuf[9]  << 8) | i2cCalibBuf[8])  ;
			  dig_P3 = ((i2cCalibBuf[11] << 8) | i2cCalibBuf[10]) ;
			  dig_P4 = ((i2cCalibBuf[13] << 8) | i2cCalibBuf[12]) ;
			  dig_P5 = ((i2cCalibBuf[15] << 8) | i2cCalibBuf[14]) ;
			  dig_P6 = ((i2cCalibBuf[17] << 8) | i2cCalibBuf[16]) ;
			  dig_P7 = ((i2cCalibBuf[19] << 8) | i2cCalibBuf[18]) ;
			  dig_P8 = ((i2cCalibBuf[21] << 8) | i2cCalibBuf[20]) ;
			  dig_P9 = ((i2cCalibBuf[23] << 8) | i2cCalibBuf[22]) ;

			  Data_sent = 0x10;
			  HAL_I2C_Mem_Write(&hi2c1, BMP280_Address, REG_BMP_CONFIG, 1, &Data_sent, 1, 10);		//Selon la datasheet, IIR filter à 16
			  Data_sent = 0x5D;
			  HAL_I2C_Mem_Write(&hi2c1, BMP280_Address, REG_BMP_CTL_MESURE, 1, &Data_sent, 1, 10); 	//Haute résolution, sampling x2 et single measurement mode
	      }
}



void MPU9250_Init(){
	uint8_t Data_sent;
	uint8_t error;
	uint8_t Chip_Id_Accel_Gyro;
	uint8_t Chip_Id_Magn;
	uint8_t i2cInitMagBuf[3];


	//------------------------Procédure de réveil et reset des composants

		//Sélection du compas et extinction en vue d'une réinitialisation
	Data_sent = 0x20;
	HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_MPU9250_USER_CTL , 1, &Data_sent, 1, 10); 					// Enable I2C master
	Data_sent = 0x0D;
	HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_MPU9250_MST_CTRL , 1, &Data_sent, 1, 10);					//Horloge interne du master à 400kHz
	error = write_Magn(REG_MAGN_CNTL1,CST_MAGN_PWR_DWN);														//Extinction du composant
	HAL_Delay(1);
		//Reset du MPU
	Data_sent = 0x80;
	HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_MPU9250_POWER, 1, &Data_sent,1, 10);
	HAL_Delay(1);


	//------------------------Initialisation de l'accéléromètre et du gyroscope

		//Identification du composant
	HAL_I2C_Mem_Read(&hi2c1, MPU9250_Address, REG_MPU9250_ACCEL_WAI, 1, &Chip_Id_Accel_Gyro,1, 10);								// Lecture du registre d'identification du MPU9250 (0x75) qui contient la valeur 0x71
	if(Chip_Id_Accel_Gyro==0x71){
		//Configuration des registres
		Data_sent = 0;
		HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_MPU9250_POWER, 1, &Data_sent, 1, 10); 							// Réveil du composant
		Data_sent = 0x07;
		HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_MPU9250_SMPRT_DIV, 1, &Data_sent, 1, 10);						//Data-rate 1kHz
		Data_sent = 0x08;
		HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_MPU9250_ACCEL_CONFIG1 , 1, &Data_sent, 1, 10); 					// Accelerometer à +/- 4g
		Data_sent = 0;
		HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_MPU9250_GYRO_CONFIG , 1, &Data_sent, 1, 10); 					//Gyro à +/- 250 °/s
	}


	//------------------------Initialisation du compas

		//Configuration de la communication et reset
	Data_sent = 0x20;
	HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_MPU9250_USER_CTL , 1, &Data_sent, 1, 10); 					// Enable I2C master
	Data_sent = 0x0D;
	HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_MPU9250_MST_CTRL , 1, &Data_sent, 1, 10);					//Horloge interne du master à 400kHz
	error = write_Magn(REG_MAGN_CNTL2,CST_MAGN_RESET);															//Reset du magnetometre
	HAL_Delay(1);

		//Identification du composant
	read_Magn(REG_MAGN_WAI,1,&Chip_Id_Magn);
	if(Chip_Id_Magn==0x48){
			//Configuration des registres et lecture de la calibration
		Data_sent = 0x0F;
		error = write_Magn(REG_MAGN_CNTL1,Data_sent);			//Autorisation d'accès aux données de calibration
		HAL_Delay(100);
		read_Magn(REG_MAGN_CALIBX,3,i2cInitMagBuf);				//Lecture des données de calibration ; Calcul issu de la datasheet ; micro Tesla
		Magn_CalibX = ((((float)i2cInitMagBuf[0])-128.0) / 256.0 + 1) * 4912.0 / 32760.0 ;
		Magn_CalibY = ((((float)i2cInitMagBuf[1])-128.0) / 256.0 + 1) * 4912.0 / 32760.0 ;
		Magn_CalibZ = ((((float)i2cInitMagBuf[2])-128.0) / 256.0 + 1) * 4912.0 / 32760.0 ;
		Data_sent = 0x16;
		error = write_Magn(REG_MAGN_CNTL1,Data_sent);			//sortie 16 bits, 100Hz update rate
		HAL_Delay(100);
	}
}

//========================================= FONCTIONS D'ACQUISITION =============================================================

void MPU9250_acqu_ACCEL_GYRO(){

	uint8_t i2cAccelGyroBuf[14];								//Buffer d'acquisition accéléromètre et gyroscope
	uint8_t Chip_Id_MPU=0;

	HAL_I2C_Mem_Read(&hi2c1, MPU9250_Address, REG_MPU9250_ACCEL_WAI, 1, &Chip_Id_MPU,1, 10);  // Lecture du registre Chip_Id du MPU9250 contenant le mot 0x71
	if(Chip_Id_MPU==0x71){

		HAL_I2C_Mem_Read(&hi2c1, MPU9250_Address, REG_MPU9250_ACCEL_OUT, 1,i2cAccelGyroBuf, 14, 10); // Lecture des 14 octets de données
			acq_AccelX = (i2cAccelGyroBuf[0] <<8 | i2cAccelGyroBuf[1]);
			acq_AccelY = (i2cAccelGyroBuf[2] <<8 | i2cAccelGyroBuf[3]);
			acq_AccelZ = (i2cAccelGyroBuf[4] <<8 | i2cAccelGyroBuf[5]);
			acq_Temp   = (i2cAccelGyroBuf[6] <<8 | i2cAccelGyroBuf[7]);
			acq_GyroX  = (i2cAccelGyroBuf[8] <<8 | i2cAccelGyroBuf[9]);
			acq_GyroY  = (i2cAccelGyroBuf[10]<<8 | i2cAccelGyroBuf[11]);
			acq_GyroZ  = (i2cAccelGyroBuf[12]<<8 | i2cAccelGyroBuf[13]);

			AccelX = acq_AccelX/8192.0;					//Conversion en g
			AccelY = acq_AccelY/8192.0;
			AccelZ = acq_AccelZ/8192.0;

			GyroX = acq_GyroX/131.0;					//Conversion en °/s
			GyroY = acq_GyroY/131.0;
			GyroZ = acq_GyroZ/131.0;

			Temp = ((acq_Temp/333.87)+21); 				// Conversion en degrès C
	}

	//Échantillonnage en tableaux glissants
	tab_ech_accelX[ech_indice_A]=AccelX;
	tab_ech_accelY[ech_indice_A]=AccelY;
	tab_ech_accelZ[ech_indice_A]=AccelZ;
	tab_ech_gyroX[ech_indice_A]=GyroX;
	tab_ech_gyroY[ech_indice_A]=GyroY;
	tab_ech_gyroZ[ech_indice_A]=GyroZ;

	if(ech_indice_A<9){ech_indice_A++;}
	else if(ech_indice_A==9){ech_indice_A=0;}
}

void MPU9250_acqu_MAGN(){

	int8_t i2cMagnBuf[7]={0};
	int16_t acqu_MagX,acqu_MagY,acqu_MagZ;

	read_Magn(REG_MAGN_OUT,7,i2cMagnBuf);			//Lecture des données

	acqu_MagX = (i2cMagnBuf[1]<<8 | i2cMagnBuf[0]);
	acqu_MagY = (i2cMagnBuf[3]<<8 | i2cMagnBuf[2]);
	acqu_MagZ = (i2cMagnBuf[5]<<8 | i2cMagnBuf[4]);

	MagnX = acqu_MagX * Magn_CalibX;
	MagnY = acqu_MagY * Magn_CalibY;
	MagnZ = acqu_MagZ * Magn_CalibZ;

	/*MagnX = acqu_MagX *( ((Magn_CalibX - 128.0)*0.5 )/ 128 + 1 );	//Calcul issu de la datasheet
	MagnY = acqu_MagY *( ((Magn_CalibY - 128.0)*0.5 )/ 128 + 1 );
	MagnZ = acqu_MagZ *( ((Magn_CalibZ - 128.0)*0.5 )/ 128 + 1 );*/

	//Échantillonnage en tableaux glissants
	tab_ech_magnX[ech_indice_M]=MagnX;
	tab_ech_magnY[ech_indice_M]=MagnY;
	tab_ech_magnZ[ech_indice_M]=MagnZ;

	if(ech_indice_M<9){ech_indice_M++;}
	else if(ech_indice_M==9){ech_indice_M=0;}
}

void BMP280_acqu_Temperature_Pression(){

	uint8_t i2cTempBuf [3] = {0} ;
	uint8_t i2cPresBuf [3] = {0} ;
	uint8_t  Data_sent = 0x5D ;    						//Config registre de configuration 0xF4 Pressionx16, Tempx2 et mode forcé
	uint32_t varT1, varT2;
	int32_t t_fine;
	int32_t TemperatureU,PressureU ;
	int32_t varP1,varP2;
	uint32_t p;


	HAL_I2C_Mem_Write(&hi2c1, BMP280_Address, REG_BMP_CTL_MESURE, 1, &Data_sent, 3, 10); 			//Demade de mesure
	HAL_Delay(44);


	//--------------------------- TEMPERATURE ------------------------- formules issues de la datasheet


	HAL_I2C_Mem_Read(&hi2c1, BMP280_Address, REG_BMP_TEMP_DATA, 1, i2cTempBuf, 3, 10);

	TemperatureU = (((i2cTempBuf[0]<<12) + (i2cTempBuf[1]<<4)) + (i2cTempBuf[2]>>4));
	varT1 = ((((TemperatureU>>3)- ((int32_t)dig_T1<<1))) * ((int32_t)dig_T2)) >> 11;
	varT2 = (((((TemperatureU >> 4) - ((int32_t)dig_T1)) * ((TemperatureU >> 4) - ((int32_t)dig_T1))) >> 12) * ((int32_t)dig_T3)) >> 14;
	t_fine = varT1 + varT2;
	Temperature = ((t_fine * 5 + 128) >> 8)/100.0 ; 						// Traitement de la température et passage en degrès celsius


	//--------------------------- PRESSION ------------------------- formules issues de la datasheet

	HAL_I2C_Mem_Read(&hi2c1, BMP280_Address, REG_BMP_PRES_DATA, 1, i2cPresBuf, 3, 10);

	PressureU = (i2cPresBuf[0]<<12) | (i2cPresBuf[1]<<4) | (i2cPresBuf[2]>>4);

	varP1 = ((int32_t)t_fine>>1) -(int32_t)64000;
	varP2 = ((varP1>>2) * (varP1>>2) >>11) * ((int32_t)dig_P6);
	varP2 = varP2 + ((varP1*((int32_t)dig_P5))<<1);
	varP2 = (varP2>>2)+(((int32_t)dig_P4)<<16);
	varP1 = (((dig_P3 * (((varP1>>2) * (varP1>>2)) >> 13))>>3) +((((int32_t)dig_P2)*varP1)>>1)) >> 18;
	varP1 = ((((32768+varP1)) * ((int32_t) dig_P1))>>15);
	if (varP1 == 0){
		varP1++; // avoid exception caused by division by zero
	}
	p = (((uint32_t)(((int32_t)1048576)-PressureU)-(varP2>>12)))*3125;
	if(p<0x80000000){
		p = (p<<1)/((uint32_t)varP1);
	}else{
		p = (p/((uint32_t)varP1))*2;
	}
	varP1 = (((int32_t)dig_P9) * ((int32_t)(((p>>3) * (p>>3))>>13)))>>12;
	varP2 = (((int32_t)(p>>2)) * ((int32_t)dig_P8))>>13;
	Pression =(uint32_t)((int32_t)p + ((varP1 + varP2 + dig_P7)>>4))/100.0;
}


//========================================= FONCTIONS COMMUNICATION MAGNETOMETRE =============================================================

/*
La communication passe par la communication Master / Slave du MPU

*/

void read_Magn(uint8_t address,uint8_t lenght, uint8_t* readMagnBuf){
		uint8_t Data_sent;
		Data_sent = Magneto_Address | 0x80;  //"0x80" passe l'adresse en mode lecture
		HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_I2C_SLV0_ADDR,1, &Data_sent,1,10);			//Selectionne le Slave 0 et prépare à la lecture
		Data_sent = address;
		HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_I2C_SLV0_REG,1, &Data_sent,1,10);			//Sélectionne le registre avec lequel on veut communiquer
		Data_sent = CST_I2C_SLV0_EN | lenght;
		HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_I2C_SLV0_CTRL,1,&Data_sent ,1,10);			//Autorise le transfert
		HAL_Delay(1);																				//Temps que le registre se remplisse
		HAL_I2C_Mem_Read(&hi2c1,MPU9250_Address,REG_EXT_SENS_DATA_00,1,readMagnBuf,lenght,10);		//Lecture du registre de sortie

}

uint8_t write_Magn(uint8_t address, uint8_t Data){
		uint8_t Data_sent;
		Data_sent = Magneto_Address;
		if(HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_I2C_SLV0_ADDR,1, &Data_sent,1,10)==HAL_ERROR) return 0xFF;	//Sélectionne le Slave 0 et prépare à l'écriture
		Data_sent = address;
		if(HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_I2C_SLV0_REG,1, &Data_sent,1,10)==HAL_ERROR) return 0xFF;
		Data_sent = Data;
		if(HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_I2C_SLV0_DO,1, &Data_sent,1,10)==HAL_ERROR) return 0xFF;
		Data_sent = CST_I2C_SLV0_EN;
		if(HAL_I2C_Mem_Write(&hi2c1, MPU9250_Address, REG_I2C_SLV0_CTRL,1,&Data_sent ,1,10)==HAL_ERROR) return 0xFF;
		HAL_Delay(1);

		return 1;
}

//========================================= FONCTIONS D'ECHANTILLONNAGE =============================================================

void echantillonnage(){

	float Num_AccelX=0,Num_AccelY=0,Num_AccelZ=0;
	float Num_GyroX=0,Num_GyroY=0,Num_GyroZ=0;
	float Num_MagnX=0,Num_MagnY=0,Num_MagnZ=0;

	//Échantillonnage de l'accélération et du gyroscope
	for(uint8_t i =0;i<10;i++){
		Num_AccelX += tab_ech_accelX[i];
		Num_AccelY += tab_ech_accelY[i];
		Num_AccelZ += tab_ech_accelZ[i];

		Num_GyroX += tab_ech_gyroX[i];
		Num_GyroY += tab_ech_gyroY[i];
		Num_GyroZ += tab_ech_gyroZ[i];

		Num_MagnX += tab_ech_magnX[i];
		Num_MagnY += tab_ech_magnY[i];
		Num_MagnZ += tab_ech_magnZ[i];
	}
	ech_AccelX = (Num_AccelX/10)*ACCEL_G;		//valeur en m/s²
	ech_AccelY = (Num_AccelY/10)*ACCEL_G;
	ech_AccelZ = (Num_AccelZ/10)*ACCEL_G;

	ech_GyroX = Num_GyroX/10;
	ech_GyroY = Num_GyroY/10;
	ech_GyroZ = Num_GyroZ/10;

	ech_MagnX = Num_MagnX/10;
	ech_MagnY = Num_MagnY/10;
	ech_MagnZ = Num_MagnZ/10;
}

void acquisition_capteurs(){

	BMP280_acqu_Temperature_Pression();
	MPU9250_acqu_MAGN();
	MPU9250_acqu_ACCEL_GYRO();
}


void TIM2_IRQHandler(void)
{
  /* USER CODE BEGIN TIM2_IRQn 0 */
	echantillonnage();
	HAL_GPIO_TogglePin(GPIOB,GPIO_PIN_3);
  /* USER CODE END TIM2_IRQn 0 */
  HAL_TIM_IRQHandler(&htim2);
  /* USER CODE BEGIN TIM2_IRQn 1 */

  /* USER CODE END TIM2_IRQn 1 */
}

//========================================= FONCTIONS D'ENABLE =============================================================

uint8_t get_Enable_acq(void){
	return Enable_acq;
}


void TIM3_IRQHandler(void)
{
  /* USER CODE BEGIN TIM3_IRQn 0 */
	Enable_acq = 1;

  /* USER CODE END TIM3_IRQn 0 */
 HAL_TIM_IRQHandler(&htim3);
  /* USER CODE BEGIN TIM3_IRQn 1 */

  /* USER CODE END TIM3_IRQn 1 */
}

