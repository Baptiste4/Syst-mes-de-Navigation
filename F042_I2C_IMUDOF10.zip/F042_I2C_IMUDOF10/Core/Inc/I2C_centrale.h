/*
 *Fichier contenant la déclaration des fonctions utilisées pour
 * l'acquisition des capteurs de la centrale inertielle.
 *
 */

//LIBRAIRIES ET FICHIERS UTILISÉS
#include "stm32f0xx_hal.h"
#include "stm32f0xx_it.h"
#include "stm32f0xx_hal_i2c.h"
#include "math.h"

//DÉCLARATION DU BUS I2C ET DE L'IT TIMER
I2C_HandleTypeDef hi2c1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;

//ADRESSE DES COMPOSANTS
#define BMP280_Address 	0xEE		//Adresse du baromètre
#define MPU9250_Address 0xD0		//Adresse de l'accéléromètre ET du gyroscope
#define Magneto_Address 0x0C		//Adresse du magnétomètre

//REGISTRES ET CONSTANTES POUR LE MAGNETOMETRE
#define REG_I2C_SLV0_ADDR		0x25		//Adresse physique I2C du slave
#define REG_I2C_SLV0_REG		0x26		//Sélectionne à quel registre commence l'intéraction avec le slave
#define REG_I2C_SLV0_CTRL		0x27		//Registre d'autorisation de lecture
#define REG_I2C_SLV0_DO			0x63		//Registre dont la data sera envoyée au slave
#define REG_EXT_SENS_DATA_00	0x49		//Registre du MPU où est stockée la valeur renvoyée par le Magneto

#define REG_MAGN_CNTL1			0x0A		//Registre Control 1 du magnetometre
#define REG_MAGN_CNTL2			0x0B		//Registre Control 2
#define REG_MAGN_WAI			0x00		//Registre Who I am
#define REG_MAGN_CALIBX			0x10		//Registre de donnée de calibration
#define REG_MAGN_OUT 			0x03
#define REG_MAGN_DATA_RDY		0x02

#define CST_I2C_SLV0_EN 		0x80		//Commande à envoyer pour l'autorisation ci-dessus
#define CST_MAGN_PWR_DWN		0x00		//Commande d'extinction du Magneto
#define CST_MAGN_RESET			0x01		//Commande de reset du magnetometre


//REGISTRES DU MPU9250
#define REG_MPU9250_ACCEL_WAI 		0x75
#define REG_MPU9250_POWER 			0x6B
#define	REG_MPU9250_ACCEL_CONFIG1 	0x1C
#define	REG_MPU9250_GYRO_CONFIG 	0x1B
#define REG_MPU9250_SMPRT_DIV 		0x19
#define REG_MPU9250_ACCEL_OUT		0x3B
#define	REG_MPU9250_USER_CTL 		0x6A
#define REG_MPU9250_MST_CTRL		0x24

//REGISTRES DU BMP280
#define REG_BMP_CTL_MESURE 			0xF4
#define REG_BMP_CONFIG				0xF5
#define REG_BMP_CALIBRATION  		0x88
#define REG_BMP_TEMP_DATA 			0xFA
#define REG_BMP_PRES_DATA			0xF7

//FONCTIONS D'INITIALISATION
void BMP280_Init(void);
void MPU9250_Init(void);

//FONCTIONS D'ACQUISITION
void MPU9250_acqu_ACCEL_GYRO(void);
void MPU9250_acqu_MAGN(void);
void BMP280_acqu_Temperature_Pression(void);
void acquisition_capteurs(void);

//FONCTIONS COMMUNICATION MAGNETOMETRE
void read_Magn(uint8_t address,uint8_t lenght, uint8_t* readMagnBuf);
uint8_t write_Magn(uint8_t address, uint8_t Data);

//FONCTION D'ÉCHANTILLONNAGE
void echantillonnage(void);

//GET DE L'ENABLE
uint8_t get_Enable_acq(void);

//CONSTANTES DE TRAITEMENT
#define ACCEL_G			9.805		//valeur de g à Bordeaux



